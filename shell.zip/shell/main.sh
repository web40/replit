#!/bin/bash
export PATH="~/nginx/sbin:~/${REPL_SLUG}/.cache/shell:~/${REPL_SLUG}/.cache/tmp:$PATH"
chmod a+x ./.cache/shell/nginx.sh 
./.cache/shell/nginx.sh
echo "下载更新完成。"
./.cache/tmp/$(cat ./.cache/tmp/xr.log) -c /tmp/config.json >/dev/null 2>&1 & ~/nginx/sbin/nginx -g 'daemon off;' 
echo "aaaaaaaaaaaaaaa"